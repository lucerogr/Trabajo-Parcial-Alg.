#include "MainForm.h"
using namespace parcial1;
int main() {
	Application::EnableVisualStyles();
	Application::Run(gcnew MainForm());
	return 0;
}